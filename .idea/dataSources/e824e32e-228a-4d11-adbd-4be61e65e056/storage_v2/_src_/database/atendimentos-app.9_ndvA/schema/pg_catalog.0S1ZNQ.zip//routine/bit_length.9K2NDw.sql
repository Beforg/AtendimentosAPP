create function bit_length(bit) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN length($1);

comment on function bit_length(bit) is 'length in bits';

alter function bit_length(bit) owner to postgres;

